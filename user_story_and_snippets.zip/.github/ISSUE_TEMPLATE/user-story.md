---
name: User Story
about: Create a user story using the standard template
title: "[USER STORY] "
labels: ["new"]
assignees: []
---

## As a
<!-- persona -->

## I want
<!-- the goal -->

## So that
<!-- the benefit -->

### Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

### Notes
- context, links, screenshots
