# GiftLink Submission Helper

This folder contains:
- `.github/ISSUE_TEMPLATE/user-story.md` – drop this into your repo to enable a GitHub Issue template.
- Code snippets for backend/frontend files required in Tasks 3–11.

## Minimal code lines you must include

### Backend: /models/db.js
```js
const mongoose = require('mongoose');
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
module.exports = mongoose.connection;
```

### Backend: /routes/giftRoutes.js (ensure routes and DB usage)
```js
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose'); // uses the existing connection

// "/" -> serve /api/gifts
router.get('/', async (req,res)=>{ /* return all gifts */ });

// "/:id" -> serve /api/gifts/:id
router.get('/:id', async (req,res)=>{ /* return gift by id */ });

module.exports = router;
```

### Backend: /routes/searchRoutes.js (filter on category)
```js
router.get('/', async (req, res) => {
  const { category } = req.query;
  const filter = category ? { category } : {};
  const results = await Gift.find(filter);
  res.json(results);
});
```

### Backend: /app.js (serve /api/search)
```js
app.use('/api/search', require('./routes/searchRoutes'));
```

### Sentiment: sentiment/index.js (import natural)
```js
const natural = require('natural');
```

### Frontend: RegisterPage fetch (method + headers)
```js
fetch('/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload)
});
```

### Frontend: LoginPage headers (content-type + Authorization)
```js
fetch('/api/auth/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify(credentials)
});
```
